package Armia;
import java.util.ArrayList;

public class Rozkaz
{
    String rozkaz;

    public Rozkaz(String r)
    {
        rozkaz = r;
    }

    public String toString()
    {
        return rozkaz;
    }
}