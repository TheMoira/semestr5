import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;
import java.io.FileNotFoundException;
// import java.io.FileWriter;  
// import java.io.IOException; 


public class Dict
{
    private String file;





    public Dict()
    {
        file = "dict.txt";



    }

    public void add(String pol, String ang)
    {
        try
        {
            FileWriter buff = new FileWriter(file,true);
            // BufferedWriter buff = new BufferedWriter(f);
            buff.write("\n" + pol + "," + ang);
            buff.close();
        }
        catch(IOException e)
        {
            System.out.println("Nie ma takiego pliku");
        }
    }

    public void delete(String word)
    {
        
    }

    public String find(String word)
    {
        String odp = "Nie ma takiego slowa w slowniku";
            
        try
        {
            Scanner in = new Scanner(new File(file)); 
            String [] line;
        

            while(in.hasNextLine())
            {
                line = in.nextLine().split(",");
                if(line[0].equals(word))
                {
                    odp = line[1];
                }
                else if(line[1].equals(word))
                {
                    odp = line[0];
                }
            }

        }
        catch(IOException e)
        {
            System.out.println("Nie ma takiego pliku");
        }


        return odp;
    }


}